import axios from "axios";
import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import "../Pokimon.css";
import {
  DetailsPokimon,
 
} from "../ReduxComponent/Reducer";

const PokimonviewComponentlist = () => {
  
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const getPokimonArray = useSelector(
    (state) => state.pokimonReducer.PokimonapiArray
  );

  const Pokimoninfo = useSelector(
    (state) => state.pokimonReducer.PokimonDetailArray
  );
  const SearchFilterArray = useSelector(
    (state) => state.pokimonReducer.PokimonSearchArray
  );
  console.log(SearchFilterArray, "SearchFilterArray");
 

  const handelInfobtn = (index_1) => {
    let id = index_1 + 1;

    if (Pokimoninfo.length !== "") {
      axios.get(`https://pokeapi.co/api/v2/pokemon/${id}/`).then((res) => {
        console.log(res.data, "data");
        dispatch(DetailsPokimon(res.data));
      });
      navigate("/pokimonDetails");
    } else {
    }
  };

  return (
    <>
      <h1 className="Head-title"> Your Pokimons Are Ready</h1>

      <div className="Pokimon-container">
        {Object.entries(getPokimonArray).map(([key_1, value_1]) => {
          return (
            <>
              {Object.entries(value_1.results).map((value_2, index_1) => {
                return (
                  <>
                    <div className="pokimon_container_item ">
                      {Object.entries(value_2).map(([key_3, value_3]) => {
                        return (
                          <>
                            <h2 className="Text-name">{value_3.name} </h2>
                          </>
                        );
                      })}
                      <h6>
                        <button
                          className="InfoBtn"
                          onClick={() => handelInfobtn(index_1)}
                        >
                          Information{" "}
                        </button>
                      </h6>
                    </div>
                  </>
                );
              })}
            </>
          );
        })}
      </div>
      {/* ): */}
    </>
  );
};

export default PokimonviewComponentlist;
