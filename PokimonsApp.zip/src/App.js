import React from "react";
import RouteComponent from "./PokimonApp/Route";

const App=()=> {
  return (
    <div className="App">
   <RouteComponent/>
    </div>
  );
}

export default App;
