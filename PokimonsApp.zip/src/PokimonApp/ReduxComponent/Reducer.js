import { createSlice } from "@reduxjs/toolkit";

const initialState={
    PokimonapiArray:[],
    PokimonDetailArray:[],
    // PokimonDetailArray_2:[],
    PokimonSearchArray:[],



};
const pokiMonApp= createSlice({
    name:"Pokimon",
    initialState:initialState,
    reducers:{
addPokimon:(state,action)=>{
    state.PokimonapiArray.push(action.payload)

},

DetailsPokimon:(state,action)=>{
    state.PokimonDetailArray=[action.payload]

},
// ImagePokimon:(state,action)=>{
//     state.PokimonDetailArray_2=[action.payload]
// },

PokimonSearchfilter:(state,action)=>{
    state.PokimonSearchArray=[...action.payload]
},
    }

})
export const{addPokimon,DetailsPokimon,ImagePokimon,PokimonSearchfilter} = pokiMonApp.actions;
export default pokiMonApp.reducer;